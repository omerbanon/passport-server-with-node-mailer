var express = require('express');
var router = express.Router();
var passport = require('passport');
var Account = require('../models/account');
var mailer= require('../modules/sendEmail');
var events = require('events');

var eventEmitter = new events.EventEmitter();
eventEmitter.on('newemail', function() {
    mailer.sendEmail();
});
 
router.get('/sendEmail', function (req, res, next) {
    setTimeout(()=>
    {
        eventEmitter.emit('newemail');
    }, 5000);
}); 
  
  

router.post('/register', function (req, res) {
    Account.register(new Account({ username: req.body.username }), req.body.password, function (err, account) {
        if (err) {
            return res.redirect('register.html');
        }
        passport.authenticate('local')(req, res, function () { 
            res.redirect('/');
        });
    });
});


router.get('/logout', function (req, res) {
    req.logout();
    res.redirect('/');
});



router.get('/check', function (req, res) {
    
    if (req.session.passport) {
        res.json({user:req.session.passport.user});
    }
    else {
       res.json({user:null});
    }
});



router.get('/members', function (req, res) {
    /*if(req.isAuthenticated())
    {

    }*/
    if (req.session.passport) {
        res.send("welcome " + req.session.passport.user);
    }
    else {
        res.redirect("/login.html");
    }
});
 

router.post('/login', passport.authenticate('local'),
    function (req, res) {
        res.json(req.session.passport.user);
    });



module.exports = router;
